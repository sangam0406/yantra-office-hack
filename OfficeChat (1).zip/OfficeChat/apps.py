from flask import Flask, render_template, request,send_file
import whisper
import csv
import gc
from googletrans import Translator
import os
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from typing_extensions import Concatenate
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI
import heapq
import urllib.request
import re
import pandas as pd
import csv
import openai
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from mutagen.mp4 import MP4
from mutagen.mp3 import EasyMP3
from flask import redirect, url_for

import random
import nltk

app = Flask(__name__)

def language(choice):
    languages = ['hi', 'bn', 'te', 'mr', 'ta', 'ur', 'gu', 'kn', 'ml', 'en']
    return languages[choice - 1] if 1 <= choice <= 10 else 'en'

def mp4tomp3(video_file_path, mp3_file_path):
    command_to_mp3 = f"ffmpeg -i {video_file_path} {mp3_file_path}"
    os.system(command_to_mp3)

def translate_transcript(text, target_lang='en'):
    translator = Translator()
    translated_text = ""
    segments = text.split()
    prev_lang = None
    current_segment = ""
    for segment in segments:
        detected_lang = translator.detect(segment).lang
        if detected_lang != prev_lang:
            if prev_lang:
                if prev_lang != 'en':
                    translated_segment = translator.translate(current_segment, src=prev_lang, dest=target_lang)
                    translated_text += translated_segment.text.strip() + " "
                else:
                    translated_text += current_segment.strip() + " "
                current_segment = ""
            prev_lang = detected_lang
        current_segment += segment + " "
    if prev_lang and prev_lang != 'en':
        translated_segment = translator.translate(current_segment.strip(), src=prev_lang, dest=target_lang)
        translated_text += translated_segment.text.strip()
    else:
        translated_text += current_segment.strip()
    return translated_text.strip()

def transcriptnormal(file_path, filename):
    model = whisper.load_model("small")
    result = model.transcribe(file_path)
    transcript = result["text"]
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(transcript)
    translated_transcript = translate_transcript(transcript)
    return translated_transcript

def translateentolang(text, target_lang):
    source_lang='en'
    translator = Translator()
    translated_text = translator.translate(text, src=source_lang, dest=target_lang)
    return translated_text.text

def save_to_txt(txt_path, title, summary_text, agenda, tasks, important):
    with open(txt_path, 'w', encoding='utf-8') as file:
        file.write("Title:\n" + title + "\n\n")
        file.write("Agenda:\n" + agenda + "\n\n")
        file.write("Summary:\n" + summary_text + "\n\n")
        file.write("Tasks:\n" + tasks + "\n\n")
        file.write("Important:\n" + important + "\n\n")

def MOMAnswer(query, document_search, chain):
    docs = document_search.similarity_search(query)
    return chain.run(input_documents=docs, question=query)

def MOM(file_path, Language, txt_path, text_meet, attendance_file_path):
    content_text = re.sub(r'\[[0-9]*\]', ' ', text_meet)
    content_text = re.sub(r'\s+', ' ', content_text)
    formatted_content_text = re.sub('[^a-zA-Z]', ' ', content_text )
    formatted_content_text = re.sub(r'\s+', ' ', formatted_content_text)

    sentence_list = nltk.sent_tokenize(content_text)
    stopwords = nltk.corpus.stopwords.words('english')

    word_frequencies = {}
    for word in nltk.word_tokenize(formatted_content_text):
        if word not in stopwords:
            if word not in word_frequencies.keys():
                word_frequencies[word] = 1
            else:
                word_frequencies[word] += 1
    maximum_frequency = max(word_frequencies.values())
    for word in word_frequencies.keys():
        word_frequencies[word] = (word_frequencies[word] / maximum_frequency)

    sentence_scores = {}
    for sent in sentence_list:
        for word in nltk.word_tokenize(sent.lower()):
            if word in word_frequencies.keys():
                if len(sent.split(' ')) < 30:
                    if sent not in sentence_scores.keys():
                        sentence_scores[sent] = word_frequencies[word]
                    else:
                        sentence_scores[sent] += word_frequencies[word]

    summary_sentences = heapq.nlargest(7, sentence_scores, key=sentence_scores.get)
    summary = ' '.join(summary_sentences)

    df = pd.read_csv(attendance_file_path)
    attendee_names = df.iloc[:, 0].tolist()

    os.environ["OPENAI_API_KEY"] = "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"
    text_splitter = CharacterTextSplitter(separator="\n", chunk_size=100, chunk_overlap=20,)
    texts = text_splitter.split_text(text_meet)
    embeddings = HuggingFaceEmbeddings()
    document_search = FAISS.from_texts(texts, embeddings)
    chain = load_qa_chain(OpenAI(),chain_type="stuff")
    queries = [
        "Provide suitable title of the meet",
        "What was the agenda of the meet? Provide in points. Maximum 3 Points. After each point end with '\n'",
        f"Mention the task allocated to each attendee for future. Provide in points. These are the attendee list {attendee_names}. In this format (Attendee1) : Task1, Task2,..,Task n;\n (Attendee2) : Task1, Task2,..,Task n;\n ...;\n (Attendee n) : Task1, Task2,..,Task n; where attendee name is in curve brackets. After each Each attendee and his/her tasks end with '\n'",
        "Mention the important topics discussed in the meet. Provide in points. After each point end with '\n'"
    ]
    i = 1
    result = []
    while i != 5:
        query = queries[i - 1]
        result.append(MOMAnswer(query, document_search, chain))
        i += 1
    title = result[0]
    agenda = result[1]
    tasks = result[2]
    important = result[3]

    if Language != 'en':
        title = translateentolang(title, target_lang=Language)
        agenda = translateentolang(agenda, target_lang=Language)
        summary = translateentolang(summary, target_lang=Language)
        tasks = translateentolang(tasks, target_lang=Language)
        important = translateentolang(important, target_lang=Language)
        save_to_txt(txt_path, title, summary, agenda, tasks, important)
    else:
        save_to_txt(txt_path, title, summary, agenda, tasks, important)

def load_attendees_from_csv(csv_file):
    with open(csv_file, 'r') as file:
        reader = csv.DictReader(file)
        attendees = []
        for row in reader:
            attendees.append(row)
    return attendees

def read_password_from_file(file_path):
    with open(file_path, 'r') as file:
        password = file.read().strip()
    return password

def send_email_with_attachment(receiver_email, subject, message, txt_path):
    sender_email = "parth.agrawal2021@vitstudent.ac.in"
    sender_password_file = "password.txt"

    sender_password = read_password_from_file(sender_password_file)

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject

    msg.attach(MIMEText(message, 'plain'))

    with open(txt_path, 'r') as file:
        attachment_content = file.read()

    part = MIMEText(attachment_content, 'plain')
    part.add_header('Content-Disposition', f'attachment; filename="{txt_path}"')
    msg.attach(part)

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, sender_password)
    text = msg.as_string()
    server.sendmail(sender_email, receiver_email, text)
    server.quit()

def taskAssign(attendance_file_path, filename, txt_path):
    attendees = load_attendees_from_csv(attendance_file_path)

    openai.api_key = os.environ["OPENAI_API_KEY"] = "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"

    if openai.api_key is None:
        print("Error: OpenAI API key not found. Please set the environment variable 'OPENAI_API_KEY'.")
    else:
        with open(filename, 'r') as file:
            transcript_text = file.read()

        def extract_tasks_and_deadlines(attendee_name, transcript_text):
            prompt = f"What tasks and deadlines were assigned to {attendee_name} in the following transcript?\n\n{transcript_text}"
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1024,
                n=1,
                stop=None,
                temperature=0.5,
            )
            return response.choices[0].message.content.strip()

        df = pd.read_csv(attendance_file_path)
        i=0
        for attendee in attendees:
            df = pd.read_csv(attendance_file_path)
            name = df.iloc[i, 0]#attendee['First name']
            tasks_and_deadlines = extract_tasks_and_deadlines(name, transcript_text)
            attendee['Tasks & Deadlines'] = tasks_and_deadlines  # Add new column

            # Send email to attendee with attachment
            email = attendee['Email']
            subject = f"Task Information and Random File for {name}"
            message = f"Dear {name},\n\n"
            message += f"Your tasks:\n{tasks_and_deadlines}\n\n"
            message += "Attached is a random file.\n\n"
            message += "Best regards,\nParth Agrawal"

            send_email_with_attachment(email, subject, message, txt_path)

            print(f"Email sent to {name} at {email} with attachment {txt_path}")
            i=i+1

        # Write updated data back to the CSV file
        with open('attendence.csv', 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=attendees[0].keys())
            writer.writeheader()
            writer.writerows(attendees)

            

        


@app.route('/')
def index():
    mom_text = None
    transcript_text = None
    if os.path.exists('MOM.txt'):
        with open('MOM.txt', 'r', encoding='utf-8') as mom_file:
            mom_text = mom_file.read()
    if os.path.exists('Transcript.txt'):
        with open('Transcript.txt', 'r', encoding='utf-8') as transcript_file:
            transcript_text = transcript_file.read()
    return render_template('index.html', mom_text=mom_text, transcript_text=transcript_text)

@app.route('/process_meeting', methods=['POST'])
def process_meeting():
    if request.method == 'POST':
        # Handle video file upload
        video_file = request.files['meeting_video']
        language_choice = int(request.form['language'])

        # Save the uploaded video file to a temporary location
        video_file_path = 'Video.mp4'
        video_file.save(video_file_path)

        # Extract audio from the video file
        audio_file_path = 'Audio.mp3'
        mp4tomp3(video_file_path, audio_file_path)

        # Process the audio file
        transcript_file_path = 'Transcript.txt'
        #text_meet = transcriptnormal(audio_file_path, transcript_file_path)
        text_meet = transcriptnormal(audio_file_path, transcript_file_path)

        # Process meeting minutes and tasks
        mom_txt_path = 'MOM.txt'
        attendance_file_path = 'attendence.csv'
        MOM(audio_file_path, language(language_choice), mom_txt_path, text_meet, attendance_file_path)

        # Assign tasks to attendees and send emails
        taskAssign(attendance_file_path, transcript_file_path, mom_txt_path)

        return redirect(url_for('index'))  # Redirect to the home page after processing

@app.route('/download_mom')
def download_mom():
    return send_file('MOM.txt', as_attachment=True)

@app.route('/download_transcript')
def download_transcript():
    return send_file('Transcript.txt', as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
